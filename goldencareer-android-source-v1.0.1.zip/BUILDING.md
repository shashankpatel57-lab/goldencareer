# Golden Career Android v1.0.1

This is a genuine Kotlin + Jetpack Compose app. It is not a website WebView wrapper.

The only WebView used is inside the dedicated protected YouTube playback activity, because YouTube's embedded player is web-based. All app screens, navigation, course lists, login, checkout, profile, chat and learning UI are native/API-driven.

## Premium video flow
1. Student opens a paid lesson in Android.
2. App calls `POST /api/v1/videos/{lessonId}/playback`.
3. Backend verifies authentication, enrollment, course validity and lesson release.
4. Backend returns the YouTube video ID only to the Android playback endpoint.
5. The app opens the embedded YouTube player inside `YoutubePlayerActivity`.
6. `FLAG_SECURE` is enabled for the entire player activity.
7. A moving user watermark is shown over the video.
8. No Open in YouTube / Share / Copy URL action is provided.

This is not cryptographic DRM. A determined technical user or an external camera cannot be fully defeated.

## Build APK
Requirements:
- Android Studio
- Android SDK 36
- JDK 17 or newer compatible with the selected Android Gradle Plugin
- Internet access for first Gradle sync

Open the extracted project in Android Studio, allow Gradle sync, then:
Build → Build App Bundle(s) / APK(s) → Build APK(s)

Debug APK is normally created under:
`app/build/outputs/apk/debug/app-debug.apk`

## Build Play Store AAB
Build → Generate Signed App Bundle / APK → Android App Bundle

Create/store your release keystore safely. Never commit release signing passwords.

## Install APK directly
On the Android phone:
1. Copy/download the APK.
2. Allow “Install unknown apps” for the browser/file manager if Android asks.
3. Tap the APK.
4. Tap Install.
5. Log in with the same Golden Career account used on the website.

## API base
`https://goldencareer.co.in/api/v1/`
