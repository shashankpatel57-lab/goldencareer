# Changelog

## 1.0.1
- Premium paid-course videos are Android-app only by default.
- Added per-user Super Admin override for premium website playback.
- Added `users.premium_web_access` defaulting to 0.
- Added Admin → Lessons for unlisted YouTube lesson configuration.
- Removed VdoCipher runtime/server dependency and Android SDK dependency.
- Added protected YouTube Android playback using `FLAG_SECURE`.
- Added moving student watermark in Android and authorized web playback.
- Removed YouTube URL exposure from public course-detail API.
- Added Android-only protected playback endpoint.
- Fixed duplicated `order_items` insert in order creation.
- Renamed protected-video session logging to `video_sessions`.
- Version bumped to 1.0.1.

## 1.0.0
- Initial Golden Career PHP/MySQL/API/native Android foundation.
