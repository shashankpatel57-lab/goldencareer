package com.goldencareer.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy=Color(0xFF0B1D35)
val Navy2=Color(0xFF17395F)
val Gold=Color(0xFFEAB547)
val Cream=Color(0xFFF7F4EC)
val Ink=Color(0xFF07111F)
val Muted=Color(0xFF637083)
val Line=Color(0xFFE2E7ED)

private val scheme=lightColorScheme(primary=Navy,onPrimary=Color.White,secondary=Gold,onSecondary=Ink,background=Color(0xFFFAFBFC),surface=Color.White,onSurface=Ink,surfaceVariant=Cream)
@Composable fun GoldenCareerTheme(content: @Composable () -> Unit){MaterialTheme(colorScheme=scheme,typography=Typography(),content=content)}
