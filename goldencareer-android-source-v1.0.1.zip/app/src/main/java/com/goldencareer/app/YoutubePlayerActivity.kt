package com.goldencareer.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class YoutubePlayerActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var watermark: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var watermarkIndex = 0

    private val moveWatermark = object : Runnable {
        override fun run() {
            val gravities = listOf(
                Gravity.TOP or Gravity.START,
                Gravity.TOP or Gravity.END,
                Gravity.BOTTOM or Gravity.END,
                Gravity.BOTTOM or Gravity.START,
                Gravity.CENTER
            )
            val lp = watermark.layoutParams as FrameLayout.LayoutParams
            lp.gravity = gravities[watermarkIndex % gravities.size]
            val m = (18 * resources.displayMetrics.density).toInt()
            lp.setMargins(m, m, m, m)
            watermark.layoutParams = lp
            watermarkIndex++
            handler.postDelayed(this, 9000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        val videoId = intent.getStringExtra("video_id").orEmpty()
        if (!Regex("^[A-Za-z0-9_-]{11}$").matches(videoId)) {
            finish()
            return
        }
        val watermarkText = intent.getStringExtra("watermark") ?: "Golden Career"

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            isLongClickable = false
            setOnLongClickListener { true }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    return request?.isForMainFrame == true
                }
            }
        }

        watermark = TextView(this).apply {
            text = watermarkText
            setTextColor(Color.WHITE)
            setBackgroundColor(0x88000000.toInt())
            textSize = 11f
            setPadding(18, 10, 18, 10)
            alpha = 0.82f
        }

        root.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(watermark, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        setContentView(root)

        val html = """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
              <style>
                html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#000}
                iframe{position:absolute;inset:0;width:100%;height:100%;border:0}
              </style>
            </head>
            <body oncontextmenu="return false">
              <iframe
                src="https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&rel=0&playsinline=1&modestbranding=1"
                allow="autoplay; encrypted-media; picture-in-picture"
                allowfullscreen>
              </iframe>
            </body>
            </html>
        """.trimIndent()
        webView.loadDataWithBaseURL("https://goldencareer.co.in/", html, "text/html", "UTF-8", null)
        handler.post(moveWatermark)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        webView.stopLoading()
        webView.loadUrl("about:blank")
        webView.destroy()
        super.onDestroy()
    }
}
