package com.goldencareer.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class TokenStore(private val context:Context){
    private val prefs=context.getSharedPreferences("gc_secure",Context.MODE_PRIVATE)
    private val alias="golden_career_token_key"
    private fun key(): SecretKey {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        (ks.getKey(alias,null) as? SecretKey)?.let{return it}
        val generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    fun saveAccessToken(token:String){
        val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());val enc=cipher.doFinal(token.toByteArray())
        prefs.edit().putString("access",Base64.encodeToString(cipher.iv+enc,Base64.NO_WRAP)).apply()
    }
    fun accessToken():String?=runCatching{
        val raw=Base64.decode(prefs.getString("access",null)?:return null,Base64.NO_WRAP);val iv=raw.copyOfRange(0,12);val data=raw.copyOfRange(12,raw.size)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv));String(cipher.doFinal(data))
    }.getOrNull()
    fun clear(){prefs.edit().clear().apply()}
}
