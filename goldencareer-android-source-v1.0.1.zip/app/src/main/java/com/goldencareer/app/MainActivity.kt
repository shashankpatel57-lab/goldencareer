package com.goldencareer.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.goldencareer.app.model.Course
import com.goldencareer.app.ui.GoldenCareerApp
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity(), PaymentResultWithDataListener {
    private lateinit var vm: AppViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Checkout.preload(applicationContext)
        vm=ViewModelProvider(this)[AppViewModel::class.java]
        setContent {
            GoldenCareerApp(
                vm=vm,
                onStartPayment={course,coupon->startPurchase(course,coupon)},
                onOpenVideo={lessonId->openProtectedYoutube(lessonId)}
            )
        }
    }

    private fun startPurchase(course:Course,coupon:String){
        lifecycleScope.launch {
            try{
                val order=vm.createOrder(course.id,coupon)
                if(!order.success){vm.paymentFailed(order.message?:"Could not create order");return@launch}
                if(order.payment_status=="paid"){vm.paymentVerified("Course unlocked");return@launch}
                val razorOrder=order.razorpay_order_id ?: run{vm.paymentFailed("Razorpay order missing");return@launch}
                val key=order.key_id ?: run{vm.paymentFailed("Razorpay Key ID missing");return@launch}
                vm.setPendingRazorOrder(razorOrder)
                val checkout=Checkout()
                checkout.setKeyID(key)
                checkout.setImage(R.drawable.ic_launcher_foreground)
                val options=JSONObject().apply{
                    put("name","Golden Career")
                    put("description",course.title)
                    put("currency",order.currency)
                    put("amount",order.amount)
                    put("order_id",razorOrder)
                    put("prefill",JSONObject().apply{
                        put("name",order.user_name?:"")
                        put("email",order.user_email?:"")
                        put("contact",order.user_mobile?:"")
                    })
                    put("theme",JSONObject().put("color","#0B1D35"))
                }
                checkout.open(this@MainActivity,options)
            }catch(t:Throwable){vm.paymentFailed(t.message?:"Payment could not start")}
        }
    }

    private fun openProtectedYoutube(lessonId:Long){
        lifecycleScope.launch {
            val playback=vm.requestVideoPlayback(lessonId)
            val videoId=playback?.video_id
            if(playback?.success!=true || videoId.isNullOrBlank()){
                Toast.makeText(this@MainActivity,playback?.message?:"Video authorization is unavailable.",Toast.LENGTH_LONG).show()
                return@launch
            }
            startActivity(Intent(this@MainActivity,YoutubePlayerActivity::class.java).apply{
                putExtra("video_id",videoId)
                putExtra("watermark",playback.watermark?.text?:"Golden Career")
            })
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID:String?,paymentData:PaymentData?){
        val paymentId=paymentData?.paymentId ?: razorpayPaymentID
        val orderId=paymentData?.orderId ?: vm.pendingRazorpayOrderId
        val signature=paymentData?.signature
        if(paymentId.isNullOrBlank()||orderId.isNullOrBlank()||signature.isNullOrBlank()){
            vm.paymentFailed("Razorpay returned incomplete verification data")
            return
        }
        vm.verifyPayment(paymentId,orderId,signature)
    }

    override fun onPaymentError(code:Int,response:String?){
        vm.paymentFailed(response?:"Payment cancelled or failed ($code)")
    }
}
