package com.goldencareer.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.goldencareer.app.data.ApiClient
import com.goldencareer.app.model.*
import com.goldencareer.app.security.TokenStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class LoadState<out T>{data object Idle:LoadState<Nothing>();data object Loading:LoadState<Nothing>();data class Data<T>(val value:T):LoadState<T>();data class Error(val message:String):LoadState<Nothing>()}

data class AppUiState(
    val authenticated:Boolean=false,
    val user:User?=null,
    val home:LoadState<HomeResponse> = LoadState.Idle,
    val courses:LoadState<CoursesResponse> = LoadState.Idle,
    val myCourses:LoadState<MyCoursesResponse> = LoadState.Idle,
    val live:LoadState<LiveResponse> = LoadState.Idle,
    val newspapers:LoadState<NewspapersResponse> = LoadState.Idle,
    val mocks:LoadState<MockTestsResponse> = LoadState.Idle,
    val profile:LoadState<ProfileResponse> = LoadState.Idle,
    val notifications:LoadState<NotificationResponse> = LoadState.Idle,
    val selectedCourse:LoadState<CourseDetailResponse> = LoadState.Idle,
    val busy:Boolean=false,
    val toast:String?=null
)

class AppViewModel(app:Application):AndroidViewModel(app){
    private val api=ApiClient.create(app)
    private val tokenStore=TokenStore(app)
    private val _ui=MutableStateFlow(AppUiState(authenticated=tokenStore.accessToken()!=null))
    val ui:StateFlow<AppUiState> = _ui.asStateFlow()
    var pendingRazorpayOrderId:String?=null
        private set

    init { if(_ui.value.authenticated) refreshAll() }

    fun consumeToast(){_ui.value=_ui.value.copy(toast=null)}
    private fun err(t:Throwable)=t.message?.takeIf{it.isNotBlank()}?:"Couldn't connect. Please try again."

    fun login(identity:String,password:String,deviceUuid:String,deviceName:String){
        viewModelScope.launch{
            _ui.value=_ui.value.copy(busy=true,toast=null)
            runCatching{api.login(mapOf("email" to identity,"password" to password,"device_uuid" to deviceUuid,"device_name" to deviceName))}
                .onSuccess{r->if(r.success&&r.tokens!=null&&r.user!=null){tokenStore.saveAccessToken(r.tokens.access_token);_ui.value=_ui.value.copy(authenticated=true,user=r.user,busy=false);refreshAll()}else _ui.value=_ui.value.copy(busy=false,toast=r.message?:"Login failed")}
                .onFailure{_ui.value=_ui.value.copy(busy=false,toast=err(it))}
        }
    }
    fun register(name:String,email:String,mobile:String,password:String){
        viewModelScope.launch{
            _ui.value=_ui.value.copy(busy=true,toast=null)
            runCatching{api.register(mapOf("name" to name,"email" to email,"mobile" to mobile,"password" to password))}
                .onSuccess{r->if(r.success&&r.tokens!=null&&r.user!=null){tokenStore.saveAccessToken(r.tokens.access_token);_ui.value=_ui.value.copy(authenticated=true,user=r.user,busy=false);refreshAll()}else _ui.value=_ui.value.copy(busy=false,toast=r.message?:"Registration failed")}
                .onFailure{_ui.value=_ui.value.copy(busy=false,toast=err(it))}
        }
    }
    fun logout(){tokenStore.clear();_ui.value=AppUiState(authenticated=false)}

    fun refreshAll(){loadHome();loadCourses();loadMyCourses();loadLive();loadNewspapers();loadMocks();loadProfile();loadNotifications()}
    fun loadHome(){viewModelScope.launch{_ui.value=_ui.value.copy(home=LoadState.Loading);runCatching{api.home()}.onSuccess{_ui.value=_ui.value.copy(home=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(home=LoadState.Error(err(it)))}}}
    fun loadCourses(q:String?=null){viewModelScope.launch{_ui.value=_ui.value.copy(courses=LoadState.Loading);runCatching{api.courses(q)}.onSuccess{_ui.value=_ui.value.copy(courses=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(courses=LoadState.Error(err(it)))}}}
    fun loadMyCourses(){viewModelScope.launch{_ui.value=_ui.value.copy(myCourses=LoadState.Loading);runCatching{api.myCourses()}.onSuccess{_ui.value=_ui.value.copy(myCourses=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(myCourses=LoadState.Error(err(it)))}}}
    fun loadLive(){viewModelScope.launch{runCatching{api.live()}.onSuccess{_ui.value=_ui.value.copy(live=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(live=LoadState.Error(err(it)))}}}
    fun loadNewspapers(){viewModelScope.launch{runCatching{api.newspapers()}.onSuccess{_ui.value=_ui.value.copy(newspapers=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(newspapers=LoadState.Error(err(it)))}}}
    fun loadMocks(){viewModelScope.launch{runCatching{api.mockTests()}.onSuccess{_ui.value=_ui.value.copy(mocks=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(mocks=LoadState.Error(err(it)))}}}
    fun loadProfile(){viewModelScope.launch{runCatching{api.profile()}.onSuccess{_ui.value=_ui.value.copy(profile=LoadState.Data(it));it.profile?.let{p->_ui.value=_ui.value.copy(user=User(p.id,p.name,p.email,p.mobile))}}.onFailure{_ui.value=_ui.value.copy(profile=LoadState.Error(err(it)))}}}
    fun loadNotifications(){viewModelScope.launch{runCatching{api.notifications()}.onSuccess{_ui.value=_ui.value.copy(notifications=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(notifications=LoadState.Error(err(it)))}}}
    fun openCourse(id:Long){viewModelScope.launch{_ui.value=_ui.value.copy(selectedCourse=LoadState.Loading);runCatching{api.course(id)}.onSuccess{_ui.value=_ui.value.copy(selectedCourse=LoadState.Data(it))}.onFailure{_ui.value=_ui.value.copy(selectedCourse=LoadState.Error(err(it)))}}}
    fun closeCourse(){_ui.value=_ui.value.copy(selectedCourse=LoadState.Idle)}

    suspend fun validateCoupon(courseId:Long,code:String):Pricing? = runCatching{api.validateCoupon(mapOf("course_id" to courseId,"coupon_code" to code)).pricing}.getOrNull()
    suspend fun createOrder(courseId:Long,coupon:String):OrderCreateResponse = api.createOrder(mapOf("course_id" to courseId,"coupon_code" to coupon,"source" to "ANDROID"))
    fun setPendingRazorOrder(orderId:String?){pendingRazorpayOrderId=orderId}
    fun paymentVerified(message:String="Course unlocked") { pendingRazorpayOrderId=null;_ui.value=_ui.value.copy(toast=message);loadMyCourses();loadCourses();loadHome();val current=(_ui.value.selectedCourse as? LoadState.Data)?.value?.course?.id;current?.let{openCourse(it)} }
    fun paymentFailed(message:String){_ui.value=_ui.value.copy(toast=message)}
    fun verifyPayment(paymentId:String,orderId:String,signature:String){
        viewModelScope.launch{
            _ui.value=_ui.value.copy(busy=true)
            runCatching{api.verifyPayment(mapOf("razorpay_payment_id" to paymentId,"razorpay_order_id" to orderId,"razorpay_signature" to signature))}
                .onSuccess{r->if(r.success&&r.payment_status=="paid")paymentVerified() else paymentFailed(r.message?:"Payment verification failed")}
                .onFailure{paymentFailed(err(it))}
            _ui.value=_ui.value.copy(busy=false)
        }
    }
    suspend fun requestVideoPlayback(lessonId:Long):VideoPlaybackResponse? =
        runCatching{api.videoPlayback(lessonId)}.getOrNull()
    fun sendChat(courseId:Long,message:String){viewModelScope.launch{runCatching{api.sendChat(mapOf("course_id" to courseId,"message" to message))}.onSuccess{_ui.value=_ui.value.copy(toast="Message sent")}.onFailure{_ui.value=_ui.value.copy(toast=err(it))}}}
}
