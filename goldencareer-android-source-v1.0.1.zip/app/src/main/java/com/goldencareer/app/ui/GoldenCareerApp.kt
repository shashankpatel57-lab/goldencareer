package com.goldencareer.app.ui

import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.goldencareer.app.AppUiState
import com.goldencareer.app.AppViewModel
import com.goldencareer.app.LoadState
import com.goldencareer.app.model.*

@Composable
fun GoldenCareerApp(vm: AppViewModel, onStartPayment: (Course, String) -> Unit, onOpenVideo: (Long) -> Unit) {
    GoldenCareerTheme {
        val ui by vm.ui.collectAsState()
        val snackbar = remember { SnackbarHostState() }
        LaunchedEffect(ui.toast) {
            ui.toast?.let { snackbar.showSnackbar(it); vm.consumeToast() }
        }
        Box(Modifier.fillMaxSize()) {
            if (ui.authenticated) MainShell(vm, ui, onStartPayment, onOpenVideo) else AuthScreen(vm)
            SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
            if (ui.busy) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

@Composable
private fun AuthScreen(vm: AppViewModel) {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Cream, Color.White))),
        contentAlignment = Alignment.Center
    ) {
        Card(
            Modifier.padding(22.dp).fillMaxWidth().widthIn(max = 520.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Navy), contentAlignment = Alignment.Center) {
                    Text("GC", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
                Text(if (register) "Create your Golden Career account" else "Welcome back", fontWeight = FontWeight.Black, fontSize = 30.sp)
                Text(if (register) "One account for website and Android learning." else "Login to continue courses, mocks and interview preparation.", color = Muted)
                if (register) OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(email, { email = it }, label = { Text(if (register) "Email" else "Email or mobile") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (register) OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(
                    onClick = {
                        if (register) vm.register(name, email, mobile, password)
                        else {
                            val uuid = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
                            vm.login(email, password, uuid, "${Build.MANUFACTURER} ${Build.MODEL}")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text(if (register) "Create Account" else "Login", fontWeight = FontWeight.Bold) }
                TextButton(onClick = { register = !register }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text(if (register) "Already registered? Login" else "New here? Create account")
                }
            }
        }
    }
}

private enum class MainTab(val label: String) { HOME("Home"), COURSES("My Courses"), LIVE("Live"), DOWNLOADS("Downloads"), CHAT("Chat") }

@Composable
private fun MainShell(vm: AppViewModel, ui: AppUiState, onStartPayment: (Course, String) -> Unit, onOpenVideo: (Long) -> Unit) {
    var tab by remember { mutableStateOf(MainTab.HOME) }
    var profileOpen by remember { mutableStateOf(false) }
    var notificationsOpen by remember { mutableStateOf(false) }
    var discoverOpen by remember { mutableStateOf(false) }
    var mocksOpen by remember { mutableStateOf(false) }
    var papersOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Navy), contentAlignment = Alignment.Center) {
                            Text("GC", color = Gold, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Golden Career", fontWeight = FontWeight.Black, fontSize = 17.sp)
                            Text("Banking Success Platform", fontSize = 10.sp, color = Muted)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { notificationsOpen = true; vm.loadNotifications() }) { Icon(Icons.Default.Notifications, "Notifications") }
                    IconButton(onClick = { profileOpen = true; vm.loadProfile() }) { Icon(Icons.Default.AccountCircle, "Profile") }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                MainTab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = {
                            Icon(
                                when (t) {
                                    MainTab.HOME -> Icons.Default.Home
                                    MainTab.COURSES -> Icons.Default.School
                                    MainTab.LIVE -> Icons.Default.LiveTv
                                    MainTab.DOWNLOADS -> Icons.Default.Download
                                    MainTab.CHAT -> Icons.Default.Chat
                                }, t.label
                            )
                        },
                        label = { Text(t.label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                MainTab.HOME -> HomeScreen(ui, vm::openCourse, { discoverOpen = true }, { mocksOpen = true; vm.loadMocks() }, { papersOpen = true; vm.loadNewspapers() })
                MainTab.COURSES -> MyCoursesScreen(ui, vm::loadMyCourses, vm::openCourse)
                MainTab.LIVE -> LiveScreen(ui, vm::loadLive)
                MainTab.DOWNLOADS -> DownloadsScreen { papersOpen = true; vm.loadNewspapers() }
                MainTab.CHAT -> ChatScreen(vm, ui)
            }
        }
    }

    if (ui.selectedCourse !is LoadState.Idle) CourseDetailDialog(ui.selectedCourse, vm::closeCourse, onStartPayment, onOpenVideo)
    if (profileOpen) ProfileDialog(ui, { profileOpen = false }, { profileOpen = false; vm.logout() })
    if (notificationsOpen) NotificationsDialog(ui) { notificationsOpen = false }
    if (discoverOpen) DiscoverDialog(ui, { discoverOpen = false }, vm::loadCourses) { discoverOpen = false; vm.openCourse(it) }
    if (mocksOpen) MockDialog(ui) { mocksOpen = false }
    if (papersOpen) NewspaperDialog(ui) { papersOpen = false }
}

@Composable
private fun StateError(text: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.CloudOff, null, tint = Muted)
        Spacer(Modifier.height(8.dp)); Text(text, color = Muted); TextButton(onClick = onRetry) { Text("Retry") }
    }
}

@Composable
private fun HomeScreen(ui: AppUiState, onCourse: (Long) -> Unit, onDiscover: () -> Unit, onMocks: () -> Unit, onPapers: () -> Unit) {
    when (val h = ui.home) {
        is LoadState.Data -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 26.dp)) {
            item { Hero(h.value.greeting) }
            item { SectionHeader("Explore Golden Career", "Everything you need for banking preparation") }
            item { QuickGrid(onDiscover, onMocks, onPapers) }
            if (h.value.live_classes.isNotEmpty()) {
                item { SectionHeader("Upcoming Live Classes", "Don't miss your next session") }
                item { LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(h.value.live_classes) { LiveCard(it) } } }
            }
            item { SectionHeader("Interview & Popular Courses", "Continue from free learning to premium interview preparation") }
            items(h.value.courses) { c -> CourseRow(c) { onCourse(c.id) } }
            if (h.value.newspapers.isNotEmpty()) {
                item { SectionHeader("Today's Newspaper", "English + Hindi e-paper") }
                items(h.value.newspapers.take(2)) { PaperRow(it) }
            }
        }
        is LoadState.Error -> StateError(h.message) {}
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
private fun Hero(greeting: String) {
    Box(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Navy, Navy2))).padding(24.dp)) {
        Column {
            Text(greeting, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Text("Prepare smarter.\nInterview stronger.", color = Color.White, fontWeight = FontWeight.Black, fontSize = 31.sp, lineHeight = 34.sp)
            Spacer(Modifier.height(10.dp))
            Text("Courses, live classes, mocks, PDFs and secure premium learning — synced with goldencareer.co.in.", color = Color(0xFFD0DAE5), fontSize = 13.sp)
        }
    }
}

@Composable private fun SectionHeader(title: String, sub: String) {
    Column(Modifier.padding(start = 18.dp, end = 18.dp, top = 26.dp, bottom = 10.dp)) {
        Text(title, fontWeight = FontWeight.Black, fontSize = 21.sp); Text(sub, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun QuickGrid(onDiscover: () -> Unit, onMocks: () -> Unit, onPapers: () -> Unit) {
    data class Quick(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val action: () -> Unit)
    val actions = listOf(
        Quick("Interview Classes", Icons.Default.RecordVoiceOver, onDiscover), Quick("Mock Tests", Icons.Default.Quiz, onMocks), Quick("News Paper", Icons.Default.Newspaper, onPapers),
        Quick("Free Courses", Icons.Default.AutoStories, onDiscover), Quick("Current Affairs", Icons.Default.Public, onDiscover), Quick("Previous Papers", Icons.Default.Description, onPapers)
    )
    Column(Modifier.padding(horizontal = 14.dp)) {
        actions.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { a ->
                    Card(Modifier.padding(4.dp).weight(1f).clickable(onClick = a.action), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(a.icon, null, tint = Navy); Spacer(Modifier.height(8.dp)); Text(a.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CourseRow(c: Course, onClick: () -> Unit) {
    Card(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(86.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Navy, Navy2))), contentAlignment = Alignment.Center) { Text("GC", color = Gold, fontWeight = FontWeight.Black, fontSize = 23.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(c.title, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(c.short_description ?: "Golden Career course", color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(7.dp))
                Text(if (c.course_type == "free") "FREE" else "₹${c.price.toInt()}", color = if (c.course_type == "free") Color(0xFF087B59) else Navy, fontWeight = FontWeight.Black)
            }
            if (c.purchased) Icon(Icons.Default.CheckCircle, "Enrolled", tint = Color(0xFF087B59)) else Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun LiveCard(l: LiveClass) {
    Card(Modifier.width(250.dp), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(9.dp).clip(RoundedCornerShape(99.dp)).background(if (l.status == "live") Color.Red else Gold)); Spacer(Modifier.width(8.dp)); Text(l.status.uppercase(), fontWeight = FontWeight.Black, fontSize = 10.sp, color = Muted) }
            Spacer(Modifier.height(8.dp)); Text(l.title, fontWeight = FontWeight.Black); Text(l.teacher ?: "Golden Career Faculty", fontSize = 11.sp, color = Muted); Text(l.starts_at, fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
private fun PaperRow(p: Newspaper) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Cream), contentAlignment = Alignment.Center) { Icon(Icons.Default.Newspaper, null, tint = Navy) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(p.newspaper_name, fontWeight = FontWeight.Bold); Text("${p.language} • ${p.paper_date}", color = Muted, fontSize = 11.sp) }
        Text(if (p.downloadable) "Download" else "View", color = Navy, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
private fun MyCoursesScreen(ui: AppUiState, onRefresh: () -> Unit, onCourse: (Long) -> Unit) {
    when (val s = ui.myCourses) {
        is LoadState.Data -> LazyColumn(contentPadding = PaddingValues(10.dp)) {
            item { SectionHeader("My Courses", "Progress follows you across web and Android") }
            if (s.value.courses.isEmpty()) item { StateError("No enrolled courses yet") {} }
            else items(s.value.courses) { c ->
                Card(Modifier.fillMaxWidth().padding(7.dp).clickable { onCourse(c.id) }, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(c.title, fontWeight = FontWeight.Black, fontSize = 18.sp); Text(c.status.uppercase(), fontSize = 10.sp, color = Muted); Spacer(Modifier.height(12.dp))
                        val p = if (c.lessons > 0) (c.completed.toFloat() / c.lessons).coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth()); Text("${(p * 100).toInt()}% complete", fontSize = 11.sp, color = Muted, modifier = Modifier.padding(top = 5.dp)); c.expires_at?.let { Text("Valid until $it", fontSize = 11.sp, color = Muted) }
                    }
                }
            }
        }
        is LoadState.Error -> StateError(s.message, onRefresh)
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable private fun LiveScreen(ui: AppUiState, onRefresh: () -> Unit) {
    when (val s = ui.live) {
        is LoadState.Data -> LazyColumn { item { SectionHeader("Live Classes", "Upcoming, live now and completed") }; items(s.value.live_classes) { Column(Modifier.padding(horizontal = 18.dp, vertical = 5.dp)) { LiveCard(it) } } }
        is LoadState.Error -> StateError(s.message, onRefresh)
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable private fun DownloadsScreen(onPapers: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Downloads", fontWeight = FontWeight.Black, fontSize = 28.sp); Text("Only admin-authorized downloadable files appear here. Protected PDFs stay inside the app viewer.", color = Muted); Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth().clickable(onClick = onPapers), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Newspaper, null); Spacer(Modifier.width(12.dp)); Column { Text("Newspapers & PDFs", fontWeight = FontWeight.Bold); Text("Open current authorized resources", color = Muted, fontSize = 11.sp) } } }
    }
}

@Composable private fun ChatScreen(vm: AppViewModel, ui: AppUiState) {
    val courses = (ui.myCourses as? LoadState.Data)?.value?.courses.orEmpty(); var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Course Chat", fontWeight = FontWeight.Black, fontSize = 27.sp); Text("Only enrolled students can post in course discussion.", color = Muted, fontSize = 12.sp); Spacer(Modifier.weight(1f))
        if (courses.isEmpty()) Text("Enroll in a course to use course chat.", color = Muted)
        else { Text("Posting to: ${courses.first().title}", fontSize = 11.sp, color = Muted); Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(text, { text = it }, placeholder = { Text("Ask or discuss…") }, modifier = Modifier.weight(1f)); IconButton(onClick = { if (text.isNotBlank()) { vm.sendChat(courses.first().id, text); text = "" } }) { Icon(Icons.Default.Send, "Send") } } }
    }
}

@Composable
private fun CourseDetailDialog(state: LoadState<CourseDetailResponse>, onClose: () -> Unit, onStartPayment: (Course, String) -> Unit, onOpenVideo: (Long) -> Unit) {
    var coupon by remember { mutableStateOf("") }
    fun openLesson(l: LessonSummary) { if (l.lesson_type == "video") onOpenVideo(l.id) }
    Dialog(onDismissRequest = onClose) {
        Card(Modifier.fillMaxWidth().heightIn(max = 720.dp), shape = RoundedCornerShape(24.dp)) {
            when (state) {
                is LoadState.Loading -> Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                is LoadState.Error -> StateError(state.message, onClose)
                is LoadState.Data -> {
                    val d = state.value; val c = d.course
                    LazyColumn {
                        item { Box(Modifier.fillMaxWidth().height(160.dp).background(Brush.linearGradient(listOf(Navy, Navy2))), contentAlignment = Alignment.Center) { Text("GC", fontSize = 52.sp, color = Gold, fontWeight = FontWeight.Black) } }
                        if (c != null) item {
                            Column(Modifier.padding(20.dp)) {
                                Text(c.title, fontSize = 25.sp, fontWeight = FontWeight.Black); Text(c.short_description ?: "", color = Muted); Spacer(Modifier.height(12.dp))
                                if (d.purchased || c.course_type == "free") Button(onClick = { d.sections.firstOrNull()?.lessons?.firstOrNull()?.let(::openLesson) }, modifier = Modifier.fillMaxWidth()) { Text("START / CONTINUE LEARNING") }
                                else Column { OutlinedTextField(coupon, { coupon = it.uppercase() }, label = { Text("Coupon (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Spacer(Modifier.height(8.dp)); Button(onClick = { onStartPayment(c, coupon) }, modifier = Modifier.fillMaxWidth()) { Text("BUY NOW • ₹${c.price.toInt()}") } }
                            }
                        }
                        d.sections.forEach { section ->
                            item { Text(section.title, fontWeight = FontWeight.Black, modifier = Modifier.padding(18.dp, 12.dp, 18.dp, 4.dp)) }
                            items(section.lessons) { l ->
                                Row(Modifier.fillMaxWidth().clickable(enabled = d.purchased || l.is_preview) { openLesson(l) }.padding(18.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(when (l.lesson_type) { "video" -> Icons.Default.PlayCircle; "pdf" -> Icons.Default.PictureAsPdf; "mock_test" -> Icons.Default.Quiz; else -> Icons.Default.Description }, null, tint = Navy)
                                    Spacer(Modifier.width(12.dp)); Text(l.title, Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium); if (!d.purchased && !l.is_preview) Icon(Icons.Default.Lock, null, tint = Muted)
                                }
                            }
                        }
                    }
                }
                else -> Unit
            }
        }
    }
}

@Composable private fun ProfileDialog(ui: AppUiState, onDismiss: () -> Unit, onLogout: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { Button(onClick = onLogout) { Text("Logout") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }, title = { Text("Profile") }, text = { Column { val p = (ui.profile as? LoadState.Data)?.value?.profile; Text(p?.name ?: ui.user?.name ?: "Student", fontWeight = FontWeight.Black, fontSize = 20.sp); Text(p?.email ?: ui.user?.email ?: "", color = Muted); p?.mobile?.let { Text(it, color = Muted) }; Spacer(Modifier.height(15.dp)); Text("Purchased Courses • Orders • Mock Tests • Bookmarks • Notes • Devices", fontSize = 12.sp, color = Muted) } })
}

@Composable private fun NotificationsDialog(ui: AppUiState, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }, title = { Text("Notifications") }, text = { LazyColumn(Modifier.heightIn(max = 420.dp)) { val n = (ui.notifications as? LoadState.Data)?.value?.notifications.orEmpty(); if (n.isEmpty()) item { Text("No notifications yet.", color = Muted) } else items(n) { x -> Column(Modifier.padding(vertical = 8.dp)) { Text(x.title, fontWeight = FontWeight.Bold); Text(x.body, fontSize = 12.sp, color = Muted) } } } })
}

@Composable private fun DiscoverDialog(ui: AppUiState, onDismiss: () -> Unit, onSearch: (String?) -> Unit, onCourse: (Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss) {
        Card(Modifier.fillMaxWidth().heightIn(max = 720.dp), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(q, { q = it }, placeholder = { Text("Search courses") }, modifier = Modifier.weight(1f), singleLine = true); IconButton(onClick = { onSearch(q) }) { Icon(Icons.Default.Search, null) } }
                when (val s = ui.courses) { is LoadState.Data -> LazyColumn { items(s.value.courses) { c -> CourseRow(c) { onCourse(c.id) } } }; is LoadState.Error -> StateError(s.message) { onSearch(q) }; else -> CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally)) }
            }
        }
    }
}

@Composable private fun MockDialog(ui: AppUiState, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }, title = { Text("Mock Tests") }, text = { LazyColumn(Modifier.heightIn(max = 460.dp)) { val m = (ui.mocks as? LoadState.Data)?.value?.mock_tests.orEmpty(); if (m.isEmpty()) item { Text("No mock tests available yet.") } else items(m) { x -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(14.dp)) { Text(x.title, fontWeight = FontWeight.Bold); Text("${x.duration_minutes} min • ${x.total_marks.toInt()} marks • ${x.access_type.uppercase()}", fontSize = 11.sp, color = Muted); Text("Server autosave/result endpoints are included.", fontSize = 10.sp, color = Muted) } } } } })
}

@Composable private fun NewspaperDialog(ui: AppUiState, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }, title = { Text("Newspaper") }, text = { LazyColumn(Modifier.heightIn(max = 460.dp)) { val p = (ui.newspapers as? LoadState.Data)?.value?.newspapers.orEmpty(); if (p.isEmpty()) item { Text("No papers published yet.") } else items(p) { PaperRow(it) } } })
}
