#!/usr/bin/env bash
set -euo pipefail
gradle :app:assembleRelease :app:bundleRelease
echo "APK/AAB outputs are under app/build/outputs/. Sign the release artifact using your protected Play keystore if signingConfig is not configured locally."
